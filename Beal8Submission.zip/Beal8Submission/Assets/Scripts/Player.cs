﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Player : MonoBehaviour {

    public float jumpSpeed;
    public GameObject Ground;

    Rigidbody rb;
    bool isGrounded = false;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            isGrounded = true;
        }
        else if (collision.gameObject.tag == "Obstacle")
            GameManager.instance.isDead = true;
    }

    private void FixedUpdate()
    {
        Vector3 pos = Ground.transform.position;
        pos.y = transform.position.y;

        transform.position = pos; 


        if (Input.GetKeyDown(KeyCode.Space) && isGrounded) {
            Jump();
            Debug.Log("");
        }
    }

    private void Jump()
    {
        rb.velocity += jumpSpeed * Vector3.up;
        isGrounded = false;
    }
}
