﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpinObject : MonoBehaviour {

    public float speed;
    public bool accelerateOverTime;

    public void FixedUpdate()
    {
        if (!GameManager.instance.isDead)
        {
            if (accelerateOverTime)
                speed += Time.deltaTime;

            Vector3 rotation = transform.eulerAngles;
            rotation.y += speed * Time.deltaTime;
            transform.eulerAngles = rotation;
        }
    }
}
