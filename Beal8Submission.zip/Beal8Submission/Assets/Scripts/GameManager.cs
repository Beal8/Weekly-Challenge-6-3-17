﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public static GameManager instance = null;

    public Vector3 gravity = new Vector3(0, -1f, 0);

    public bool isDead = false;

    public int timeFontSize = 10;
    public int endFontSize = 20;

    Rect textArea;

    float time = 0;

    GUIStyle fontstyle = new GUIStyle();

    public GameObject[] allGO;

	// Use this for initialization
	void Awake () {
        textArea = new Rect(0, 0, Screen.width, Screen.height);

        Physics.gravity = gravity;

        if (instance == null)
            instance = this;
        else
            Destroy(instance);

        foreach (GameObject go in allGO)
            go.SetActive(true);
    }

    private void Update()
    {
        if (!isDead)
            time += Time.deltaTime;
        else
            foreach (GameObject go in allGO) {
                go.SetActive(false);
            }

    }

    private void OnGUI()
    {

        if (isDead)
        {
            GUI.skin.label.fontSize = endFontSize;
            fontstyle.fontSize = endFontSize;
            fontstyle.normal.textColor = Color.red;
            textArea = new Rect(200, 200, Screen.width, Screen.height);
            GUI.Label(textArea, "You die !!!!! after " + (int)time + "s", fontstyle);
        }
        else
        {
            GUI.skin.label.fontSize = timeFontSize;
            GUI.Label(textArea, (int)time + "s");
        }
    }
}
