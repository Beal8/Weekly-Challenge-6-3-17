﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public float jumpHeight;

	Rigidbody rigidbody;

	void Start() {
		rigidbody = GetComponent<Rigidbody>();
	}

	void Update() {
		if (Input.GetMouseButtonDown(0)) {
			rigidbody.AddForce(Vector3.up * jumpHeight);
		}
	}
}
