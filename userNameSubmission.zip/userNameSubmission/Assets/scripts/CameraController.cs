﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

	public float rotateSpeed = 5;

	void Update() {
		transform.RotateAround(Vector3.zero, Vector3.up, rotateSpeed * Time.deltaTime);
	}
}
